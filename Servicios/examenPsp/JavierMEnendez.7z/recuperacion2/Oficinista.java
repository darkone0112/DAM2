package recuperacion2;
public class Oficinista implements Runnable{
    private int numeroDocumentos;
    private String nombre;

    public Oficinista(String nombre,int numeroDocumentos){
        this.numeroDocumentos=numeroDocumentos;
        this.nombre=nombre;
    }

    @Override
    public void run(){
        for(int i=0;i<this.numeroDocumentos;i++){
            try {
                Thread.sleep((long) (Math.random()*6000)+5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Documento d = new Documento(this.nombre+"doc"+i);            
            try {
                Impresora.instancia().imprimir(d);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
}

