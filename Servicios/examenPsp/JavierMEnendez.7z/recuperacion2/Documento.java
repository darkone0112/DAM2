package recuperacion2;
public class Documento {
    private String content;

    public Documento(String content) {
        this.content = content;
    }
    
    @Override 
    public String toString() {
        return this.content;
    }
}
