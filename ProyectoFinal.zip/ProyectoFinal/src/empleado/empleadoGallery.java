public class empleadoGallery {
    //gallery classs to implement EMpleadoInterface
    public static EmpleadoInterface getEmpleadoDao(){
        return new EmpleadoBean();
    }
    
}
