package com.example.peliculasactores;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import PeliculasAPI.PeliculaViewModel;

public class DetallePelicula extends AppCompatActivity {

    TextView Nombre, Description, Estrellas, Actores;
    ImageView EImage;
    ProgressBar progess;
    private String nombre;

    private PeliculaViewModel vm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_pelicula);

        Nombre = findViewById(R.id.nombre);
        Description = findViewById(R.id.descripcion);
        Estrellas = findViewById(R.id.estrellas);
        Actores = findViewById(R.id.actores);
        progess = findViewById(R.id.progressBar);

        nombre = getIntent().getStringExtra("nombre");

        vm = new ViewModelProvider(this).get(PeliculaViewModel.class);
        vm.init();

        vm.getDataPelicula().observe(this, (data) -> {

            Nombre.setText(data.getNombre());
            Description.setText(data.getDescripcion());
            Estrellas.setText(data.getEstrellas());

        });
        vm.mostrarDetalle(nombre);
    }

    public void insertarImagenes(String nombre) {

        String imgURL = "https://api.genshin.dev/characters/"+nombre+"/gacha-splash";

        progess.setVisibility(View.INVISIBLE);
        Glide.with(EImage)
                .load(imgURL)
                .into(EImage);

        Nombre.setVisibility(View.VISIBLE);
        Description.setVisibility(View.VISIBLE);
        Estrellas.setVisibility(View.VISIBLE);


    }


}