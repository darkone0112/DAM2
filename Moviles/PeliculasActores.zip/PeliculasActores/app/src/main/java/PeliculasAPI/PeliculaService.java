package PeliculasAPI;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface PeliculaService {

    @GET("/pmdm/api/peliculas")
    Call <List<Respuesta>> mostrarPelicula();





    @GET("/pmdm/api/peliculas{nombre}")
    Call <InfoPelicula> mostrarDescripcion(
            @Path("nombre") String nombre);

}