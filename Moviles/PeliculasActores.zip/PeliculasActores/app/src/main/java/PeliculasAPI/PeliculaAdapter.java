package PeliculasAPI;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.peliculasactores.R;

import java.util.ArrayList;
import java.util.List;

public class PeliculaAdapter extends RecyclerView.Adapter<PeliculaAdapter.PeliculaAdapterResultHolder> {

    private List<Respuesta> results = new ArrayList<>();
    private onItemClickListener mListener;




    @NonNull
    @Override
    public PeliculaAdapterResultHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_row_pelicula, parent, false);
        return new PeliculaAdapterResultHolder(itemView);
    }

    public void setmListener(onItemClickListener mListener) {
        this.mListener = mListener;
    }

    @Override
    public void onBindViewHolder(@NonNull PeliculaAdapterResultHolder holder, int position) {

        holder.nEstrellas.setText((CharSequence) results.get(position));
        holder.nombrePelicula.setText((CharSequence) results.get(position));
        holder.descPelicula.setText((CharSequence) results.get(position));

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mListener != null) {
                    int position = holder.getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION) {
                        mListener.onItemClick(position);
                    }
                }
            }
        });

    }

    public List<Respuesta> getResults() {
        return results;
    }

    public void setResults(List<Respuesta> results) {
        this.results = results;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return results.size();
    }

    class PeliculaAdapterResultHolder extends RecyclerView.ViewHolder {
        private TextView nEstrellas;
        private TextView nombrePelicula;
        private TextView descPelicula;

        public PeliculaAdapterResultHolder(@NonNull View itemView) {
            super(itemView);

            nEstrellas = itemView.findViewById(R.id.nEstrellas);
            nombrePelicula = itemView.findViewById(R.id.nombrePelicula);
            descPelicula = itemView.findViewById(R.id.descPelicula);
        }
    }

    public interface onItemClickListener{
        void onItemClick(int position);
    }

}

