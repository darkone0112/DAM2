package PeliculasAPI;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class InfoPelicula {

    @SerializedName("nombre")
    @Expose
    private String nombre;

    @SerializedName("descripcion")
    @Expose
    private String descripcion;

    @SerializedName("estrellas")
    @Expose
    private String estrellas;

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getEstrellas() {
        return estrellas;
    }

}


